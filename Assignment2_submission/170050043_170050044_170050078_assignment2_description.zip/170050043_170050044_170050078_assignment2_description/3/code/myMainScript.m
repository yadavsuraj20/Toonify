%% MyMainScript

tic;
%% Your code here
myPatchBasedFiltering('../../2/data/grass.png')
myPatchBasedFiltering('../../2/data/honeyCombReal.png')
myPatchBasedFiltering('../../2/data/barbara.mat')
% gaussianMask
toc;
