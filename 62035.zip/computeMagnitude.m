function gradientMagnitude = computeMagnitude(xGradient,yGradient)
gradientMagnitude = sqrt(xGradient.^2 + yGradient.^2);
end